package com.demo.COSC2P03.assignment3.src.storage;

/**
 * Ah dernit, mah dang heap ain't heapin'!
 */
public class HeapOTroubleException extends RuntimeException {
}
