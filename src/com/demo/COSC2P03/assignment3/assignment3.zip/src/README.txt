HEAP TREE

1. Node - item, lef, right



2. heap class
 - index

i. insert
- create new Node
- ++index
- insert new item ate index
parentIndex = index/2

index % 2 == 0 ? left : right

insert



ii. getAtIndex

breadth first/level search
and count from root == 1



